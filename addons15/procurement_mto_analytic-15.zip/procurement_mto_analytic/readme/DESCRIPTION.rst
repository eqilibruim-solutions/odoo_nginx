This module takes account analytic value from sale order to the created
purchase order line.
