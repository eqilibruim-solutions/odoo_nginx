================================
Picking and Reservation Strategy
================================

* Allows to automatically build optimal picking routes and apply custom reservation options.

|

Changelog
=========

* 1.0.2 (2021-11-30)
    - [FIX] Fixing issue with compute method for strategy_sequence field on stock.location. That was causing issues in POS module
