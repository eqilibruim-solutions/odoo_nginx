Product Multiple Barcodes
=========================

This module allows to define multiple additional barcodes for products and to search products by additional barcodes and internal reference.

Changelog
---------

14.0.1.0.1 (2021-06-16)
***********************

* Changing of checking for uniqueness barcodes only by active products

14.0.1.0.0 (2021-05-18)
***********************

Improved validation message for cases when duplicate barcode found in other product.