odoo.define('root.widget', function (require) {
"use strict";

var webClient = require('web.web_client');

return webClient;
});
