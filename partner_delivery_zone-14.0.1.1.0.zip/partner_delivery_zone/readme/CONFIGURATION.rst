To configure this module you need to:

#. Go to *Sales > Configuration> Delivery Zones* and create any zones
