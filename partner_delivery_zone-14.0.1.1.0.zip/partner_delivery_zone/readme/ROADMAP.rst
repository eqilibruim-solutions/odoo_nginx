* For the future, system can set delivery zones based on partner zip.
